package com.voiceagent.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var hfBtn: Button
    private lateinit var hfInfo: TextView
    private lateinit var stMic: TextView
    private lateinit var stNote: TextView
    private lateinit var stAcc: TextView
    private lateinit var stBat: TextView
    private lateinit var keyE: EditText
    private lateinit var modelE: EditText
    private lateinit var wakeE: EditText
    private lateinit var cmdE: EditText
    private lateinit var voiceG: RadioGroup
    private lateinit var shotS: Switch
    private lateinit var wakeS: Switch

    private val BG = 0xFF0E0F1F.toInt()
    private val CARD = 0xFF171933.toInt()
    private val MUTED = 0xFFA9ACD3.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(c: Int, r: Int = 14): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(c)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun gradient(r: Int = 16): GradientDrawable {
        val g = GradientDrawable()
        g.setColors(intArrayOf(0xFF7C4DFF.toInt(), 0xFF00B0FF.toInt()))
        g.setOrientation(GradientDrawable.Orientation.LEFT_RIGHT)
        g.cornerRadius = dp(r).toFloat()
        return g
    }

    private fun lp(top: Int = 10): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(top)
        return p
    }

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        return v
    }

    private fun edit(hint: String, value: String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(0xFF7F82A8.toInt())
        e.background = rounded(0xFF22244A.toInt())
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        return e
    }

    private fun button(t: String, accent: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = t
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.background = if (accent) gradient() else rounded(0xFF2B2E5A.toInt())
        b.setOnClickListener { onClick() }
        return b
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(CARD, 20)
        c.setPadding(dp(16), dp(16), dp(16), dp(16))
        c.addView(label(title, 16f, Color.WHITE, true))
        parent.addView(c, lp(14))
        return c
    }

    private fun setupRow(parent: LinearLayout, btnText: String, onClick: () -> Unit): TextView {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val tv = label("", 14f, Color.WHITE)
        row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val b = button(btnText, false, onClick)
        b.textSize = 12f
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(dp(14), dp(8), dp(14), dp(8))
        row.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40)))
        parent.addView(row, lp(8))
        return tv
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = ScrollView(this)
        root.setBackgroundColor(BG)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(40), dp(18), dp(40))
        root.addView(col)

        col.addView(label("🎙️ Voice Agent", 28f, Color.WHITE, true))
        col.addView(label("आपका फ्री, हैंड्स-फ्री Gemini साथी", 14f, MUTED), lp(4))

        // --- Hands-free card
        val c1 = card(col, "हैंड्स-फ्री मोड")
        hfInfo = label("", 13f, MUTED)
        c1.addView(hfInfo, lp(8))
        hfBtn = button("", true) { toggleHf() }
        hfBtn.textSize = 16f
        c1.addView(hfBtn, lp(12))

        // --- Setup card
        val c2 = card(col, "Setup (एक बार)")
        stMic = setupRow(c2, "Allow") { requestPerms() }
        stNote = setupRow(c2, "Allow") { requestPerms() }
        stAcc = setupRow(c2, "ON करो") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        stBat = setupRow(c2, "छूट दो") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        c2.addView(label(
            "Android 13+ पर Accessibility ग्रे दिखे तो: Settings > Apps > Voice Agent > ⋮ > 'Allow restricted settings', फिर दोबारा ON करें।",
            12f, MUTED), lp(10))

        // --- Settings card
        val c3 = card(col, "सेटिंग्स")
        keyE = edit("Gemini API key (aistudio.google.com/apikey)", Prefs.key(this))
        c3.addView(keyE, lp(10))
        modelE = edit("Model", Prefs.model(this))
        c3.addView(modelE, lp(8))

        c3.addView(label("आवाज़", 13f, MUTED), lp(14))
        voiceG = RadioGroup(this)
        voiceG.orientation = RadioGroup.HORIZONTAL
        val f = RadioButton(this); f.text = "👩 Female"; f.id = 1001; f.setTextColor(Color.WHITE)
        val m = RadioButton(this); m.text = "👨 Male"; m.id = 1002; m.setTextColor(Color.WHITE)
        voiceG.addView(f); voiceG.addView(m)
        voiceG.check(if (Prefs.voice(this) == "male") 1002 else 1001)
        c3.addView(voiceG, lp(4))

        wakeS = Switch(this)
        wakeS.text = "Wake word से जागे (सुझाया गया)"
        wakeS.setTextColor(Color.WHITE)
        wakeS.isChecked = Prefs.wakeOn(this)
        c3.addView(wakeS, lp(12))
        wakeE = edit("Wake word", Prefs.wake(this))
        c3.addView(wakeE, lp(6))

        shotS = Switch(this)
        shotS.text = "Screenshot भी Gemini को भेजो (बेहतर समझ)"
        shotS.setTextColor(Color.WHITE)
        shotS.isChecked = Prefs.shot(this)
        c3.addView(shotS, lp(12))

        c3.addView(button("💾 Save", true) { save(); toast("Saved ✅") }, lp(14))
        c3.addView(button("🔊 Voice test", false) {
            val s = AgentService.instance
            if (s == null) toast("पहले Accessibility ON कीजिए")
            else { save(); s.speak("नमस्ते! मैं आपकी साथी हूँ। बताइए, क्या करना है?") }
        }, lp(8))

        // --- Typed test card
        val c4 = card(col, "बिना बोले टेस्ट")
        cmdE = edit("जैसे: YouTube खोलकर Mr Bisht का वीडियो चलाओ", "")
        c4.addView(cmdE, lp(10))
        c4.addView(button("▶ Run", true) {
            val s = AgentService.instance
            if (s == null) toast("पहले Accessibility ON कीजिए")
            else if (cmdE.text.isNotBlank()) { save(); s.runCommand(cmdE.text.toString()) }
        }, lp(8))

        // --- Tips card
        val c5 = card(col, "ऐसे बोलिए")
        c5.addView(label(
            "• \"साथी, YouTube पर Mr Bisht सर्च करो, पहला वीडियो चलाओ और like करो\"\n" +
            "• \"साथी, Chrome खोलकर इस वेबसाइट को सर्च करो और पढ़कर सुनाओ\"\n" +
            "• \"साथी, इस वीडियो में नीचे स्क्रॉल करके बताओ क्या-क्या है\"\n" +
            "• \"साथी, Rahul को कॉल करो\"\n" +
            "• \"साथी, सुबह 6 बजे का अलार्म लगाओ\"\n" +
            "• \"साथी, सो जाओ\" (हैंड्स-फ्री बंद)\n\n" +
            "काम पूरा होने तक वो चुप रहता है, फिर सब बताता है। उसके बाद ~15 सेकंड तक बिना wake word के अगला कमांड दे सकते हैं।",
            13f, MUTED), lp(8))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun tick(ok: Boolean) = if (ok) "✅ " else "⬜ "

    private fun accOn(): Boolean {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName)
    }

    private fun batteryOk(): Boolean {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(packageName)
    }

    private fun refresh() {
        val on = Prefs.hf(this) && AgentService.instance != null
        hfBtn.text = if (on) "🛑  Hands-free बंद करो" else "🎧  Hands-free शुरू करो"
        hfBtn.background = if (on) rounded(0xFFD32F2F.toInt(), 16) else gradient()
        hfInfo.text = if (on) "सुन रहा हूँ… बोलिए: \"" + Prefs.wake(this) + ", YouTube खोलो\""
        else "शुरू करने के बाद फोन को हाथ लगाए बिना बोलते जाइए।"
        stMic.text = tick(has(Manifest.permission.RECORD_AUDIO) && has(Manifest.permission.CALL_PHONE) && has(Manifest.permission.READ_CONTACTS)) + "माइक / कॉल / कॉन्टैक्ट"
        stNote.text = tick(Build.VERSION.SDK_INT < 33 || has(Manifest.permission.POST_NOTIFICATIONS)) + "Notification"
        stAcc.text = tick(accOn()) + "Accessibility (स्क्रीन कंट्रोल)"
        stBat.text = tick(batteryOk()) + "Battery छूट (बैकग्राउंड के लिए)"
    }

    private fun requestPerms() {
        val list = arrayListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(list.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun toggleHf() {
        if (Prefs.hf(this) && AgentService.instance != null) { stopHf(); return }
        if (!has(Manifest.permission.RECORD_AUDIO)) { toast("पहले माइक permission दीजिए"); requestPerms(); return }
        if (!accOn() || AgentService.instance == null) { toast("पहले Accessibility ON कीजिए"); return }
        if (keyE.text.isBlank()) { toast("पहले API key डालिए"); return }
        save()
        startForegroundService(Intent(this, HandsFreeService::class.java))
        AgentService.instance?.setHandsFree(true)
        refresh()
        toast("Hands-free चालू ✅ — अब बोलिए")
    }

    private fun stopHf() {
        AgentService.instance?.setHandsFree(false)
        Prefs.setHf(this, false)
        stopService(Intent(this, HandsFreeService::class.java))
        refresh()
    }

    private fun save() {
        val voice = if (voiceG.checkedRadioButtonId == 1002) "male" else "female"
        Prefs.save(
            this, keyE.text.toString(), modelE.text.toString().ifBlank { "gemini-2.5-flash" },
            voice, shotS.isChecked, wakeS.isChecked, wakeE.text.toString()
        )
        AgentService.instance?.applyVoice()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
