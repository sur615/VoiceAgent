# Voice Agent (Gemini) v2 — Hands-free

GitHub पर APK बनाना:
1. नया repo बनाइए, इस ZIP की सारी फाइलें अपलोड कीजिए (`.github` फोल्डर समेत)।
2. Actions टैब > "Build APK" चलेगा (या Run workflow)।
3. 5-8 मिनट बाद Artifacts से `VoiceAgent-APK` डाउनलोड करके APK install कीजिए।

फोन में:
1. ऐप खोलिए, API key डालकर Save कीजिए (aistudio.google.com/apikey)।
2. Setup में सारे ⬜ को ✅ कीजिए (permissions, Accessibility, Battery छूट)।
3. "Hands-free शुरू करो" दबाइए। फिर बोलिए: "साथी, YouTube खोलो ..."।
