package com.voiceagent.app

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("agent", Context.MODE_PRIVATE)
    fun key(c: Context): String = sp(c).getString("key", "") ?: ""
    fun model(c: Context): String = sp(c).getString("model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
    fun voice(c: Context): String = sp(c).getString("voice", "female") ?: "female"
    fun shot(c: Context): Boolean = sp(c).getBoolean("shot", true)
    fun wakeOn(c: Context): Boolean = sp(c).getBoolean("wakeOn", true)
    fun wake(c: Context): String = sp(c).getString("wake", "साथी") ?: "साथी"
    fun hf(c: Context): Boolean = sp(c).getBoolean("hf", false)
    fun setHf(c: Context, v: Boolean) { sp(c).edit().putBoolean("hf", v).apply() }
    fun save(c: Context, key: String, model: String, voice: String, shot: Boolean, wakeOn: Boolean, wake: String) {
        sp(c).edit().putString("key", key.trim()).putString("model", model.trim())
            .putString("voice", voice).putBoolean("shot", shot)
            .putBoolean("wakeOn", wakeOn).putString("wake", wake.trim().ifBlank { "साथी" }).apply()
    }
}
