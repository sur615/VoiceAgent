package com.voiceagent.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs

class AgentService : AccessibilityService() {

    companion object {
        @Volatile var instance: AgentService? = null
        const val MAX_STEPS = 25

        const val SYSTEM = """You are "Saathi", a warm, friendly Hindi voice assistant that operates the user's Android phone hands-free. The user may speak Hindi, Hinglish or English.
Each turn you get: the user's command, recent conversation, notes gathered so far, previous actions of this command, and the CURRENT SCREEN (numbered elements, maybe plus a screenshot).
Reply with ONLY one JSON object:
{"action":{...} or null,"notes":"cumulative facts you have read/seen so far (keep important text)","done":true or false,"report":"only when done=true"}

VERY IMPORTANT: Never talk to the user while working. The phone speaks ONLY the "report", after done=true. Finish the WHOLE command first, then report.
The report: friendly, natural Hindi (Devanagari; English brand names and video titles allowed), like a helpful friend, 2-6 sentences. Say what you did and what you found (video title, channel, likes, description, comments, page text, available options...). If the user asked you to read something aloud, read its actual text from notes. End by gently asking what to do next.

Action types (exactly one per turn):
{"type":"open_app","name":"YouTube"}
{"type":"open_url","url":"https://..."}
{"type":"click","index":N}
{"type":"long_press","index":N}
{"type":"click_text","text":"..."}
{"type":"type","index":N,"text":"...","enter":true|false}   (index optional: uses the focused field)
{"type":"scroll","direction":"down"|"up"}
{"type":"tap","x":N,"y":N}
{"type":"call","target":"contact name or number"}
{"type":"alarm","hour":H,"minute":M,"label":"..."}
{"type":"volume","direction":"up"|"down"|"mute"}
{"type":"back"} {"type":"home"} {"type":"recents"} {"type":"notifications"} {"type":"quick_settings"} {"type":"lock"} {"type":"screenshot"}
{"type":"wait","seconds":N}

Rules:
- One action per turn. Use element indexes from the CURRENT SCREEN only.
- If the user says to use Chrome: open_app Chrome, click the address bar (desc/text like "Search or type web address"), type the query/URL with enter=true.
- YouTube search: open_url https://www.youtube.com/results?search_query=<urlencoded query>, then click the first video result. To like: click the element whose desc contains "like". To subscribe: click "Subscribe" (skip if it already says "Subscribed"). If player controls are hidden, tap the video once.
- To read or describe a page/video: scroll down repeatedly (up to about 6 times), adding what you see to notes (title, channel, likes, description, comments...), then report.
- The user's explicit command is permission to act (typing the email/password they said, sending a message they asked for, making a call). Use credentials ONLY if the user said them in the command; never invent them. For payments, money transfers or deleting accounts/data: do NOT do it; in the report ask the user to do it themselves.
- If the screen shows sign-in options and the user gave no details, report the available options and ask what to enter.
- Pure questions or chat: action null, done=true, answer in report.
- If something fails, try another way a few times, then report honestly what happened."""
    }

    private var wm: WindowManager? = null
    private var bubble: TextView? = null
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())
    private val nodeMap = ArrayList<AccessibilityNodeInfo>()
    private val history = ArrayList<String>()

    @Volatile private var running = false
    @Volatile private var cancelled = false
    @Volatile var handsFreeEnabled = false
    @Volatile private var armedUntil = 0L
    @Volatile private var listening = false
    @Volatile private var listenStartedAt = 0L
    @Volatile private var lastSpeakAt = 0L
    private val speaking = AtomicInteger(0)

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onServiceConnected() {
        instance = this
        Prefs.setHf(this, false)
        handsFreeEnabled = false
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                applyVoice()
                tts?.setOnUtteranceProgressListener(progress)
                speak("हेलो! मैं तैयार हूँ।")
            }
        }
        addBubble()
        main.postDelayed(watchdog, 5000)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        handsFreeEnabled = false
        main.removeCallbacksAndMessages(null)
        try { bubble?.let { wm?.removeView(it) } } catch (_: Exception) {}
        try { recognizer?.destroy() } catch (_: Exception) {}
        tts?.shutdown()
        return super.onUnbind(intent)
    }

    // ---------------- Voice out ----------------

    private val progress = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {}
        override fun onDone(utteranceId: String?) { speakEnded() }
        override fun onError(utteranceId: String?) { speakEnded() }
        override fun onStop(utteranceId: String?, interrupted: Boolean) { speakEnded() }
    }

    private fun speakEnded() {
        if (speaking.decrementAndGet() <= 0) {
            speaking.set(0)
            main.post { if (handsFreeEnabled && !running) scheduleListen(450) }
        }
    }

    fun applyVoice() {
        val t = tts ?: return
        val female = Prefs.voice(this) == "female"
        try { t.setLanguage(Locale("hi", "IN")) } catch (_: Exception) {}
        try {
            val vs = (t.voices ?: emptySet()).filter { it.locale.language == "hi" && !it.isNetworkConnectionRequired }
            val pick = vs.firstOrNull { v ->
                val n = v.name.lowercase()
                val f = (v.features ?: emptySet<String>()).joinToString(" ").lowercase()
                val isFemale = n.contains("female") || f.contains("female")
                val isMale = !isFemale && (n.contains("male") || f.contains("male"))
                if (female) isFemale else isMale
            }
            if (pick != null) t.setVoice(pick)
        } catch (_: Exception) {}
        t.setPitch(if (female) 1.12f else 0.78f)
        t.setSpeechRate(0.95f)
    }

    fun speak(text: String) {
        val t = tts ?: return
        speaking.incrementAndGet()
        lastSpeakAt = System.currentTimeMillis()
        main.post { stopRecognizer() } // don't hear myself
        val r = t.speak(text.take(3500), TextToSpeech.QUEUE_ADD, null, UUID.randomUUID().toString())
        if (r != TextToSpeech.SUCCESS) { if (speaking.decrementAndGet() < 0) speaking.set(0) }
    }

    // ---------------- Voice in (hands-free loop) ----------------

    private val listenRunnable = Runnable { startRecognizer(false) }

    private fun scheduleListen(delay: Long) {
        main.removeCallbacks(listenRunnable)
        main.postDelayed(listenRunnable, delay)
    }

    private val watchdog = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (speaking.get() > 0 && now - lastSpeakAt > 60000) speaking.set(0)
            if (listening && now - listenStartedAt > 25000) stopRecognizer()
            if (handsFreeEnabled && !running && !listening && speaking.get() == 0) scheduleListen(0)
            main.postDelayed(this, 5000)
        }
    }

    fun setHandsFree(on: Boolean) {
        handsFreeEnabled = on
        Prefs.setHf(this, on)
        main.post {
            if (on) { setBubble("🎧"); scheduleListen(300) }
            else { main.removeCallbacks(listenRunnable); stopRecognizer(); setBubble("🎤") }
        }
    }

    private fun idleIcon() = if (handsFreeEnabled) "🎧" else "🎤"

    private fun stopRecognizer() {
        try { recognizer?.cancel() } catch (_: Exception) {}
        listening = false
    }

    /** Must run on main thread. direct = bubble tap (no wake word needed). */
    private fun startRecognizer(direct: Boolean) {
        if (!direct && !handsFreeEnabled) return
        if (running || speaking.get() > 0) return
        if (Prefs.key(this).isBlank()) { handsFreeEnabled = false; speak("पहले ऐप में Gemini API key डालिए।"); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            speak("इस फ़ोन में speech recognition उपलब्ध नहीं है।")
            return
        }
        try { recognizer?.destroy() } catch (_: Exception) {}
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = r
        listening = true
        listenStartedAt = System.currentTimeMillis()
        setBubble(if (direct || System.currentTimeMillis() < armedUntil) "👂" else idleIcon())
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onError(e: Int) { listening = false; onRecogError(e, direct) }
            override fun onResults(res: Bundle?) {
                listening = false
                val t = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) afterListen() else handleSpeech(t, direct)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        r.startListening(i)
    }

    private fun afterListen() {
        if (handsFreeEnabled && !running && speaking.get() == 0) scheduleListen(250)
        else if (!handsFreeEnabled) setBubble(idleIcon())
    }

    private fun onRecogError(e: Int, direct: Boolean) {
        if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
            setHandsFree(false)
            speak("माइक की permission नहीं है। ऐप खोलकर permission दीजिए।")
            return
        }
        if (handsFreeEnabled) {
            val d = when (e) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 250L
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> 1500L
                else -> 1200L
            }
            scheduleListen(d)
        } else {
            setBubble(idleIcon())
            if (direct && (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT))
                speak("सुनाई नहीं दिया, फिर से बोलिए।")
        }
    }

    private fun handleSpeech(text: String, direct: Boolean) {
        val now = System.currentTimeMillis()
        var cmd: String? = null
        if (direct || now < armedUntil || !Prefs.wakeOn(this)) {
            cmd = text.trim()
        } else {
            val low = text.lowercase()
            val src = if (low.length == text.length) text else low
            val words = (listOf(Prefs.wake(this)) + listOf("साथी", "saathi", "sathi", "साथि", "सथी"))
                .map { it.lowercase().trim() }.filter { it.isNotEmpty() }.distinct()
            var best = -1
            var bestLen = 0
            for (w in words) {
                val i = low.indexOf(w)
                if (i >= 0 && (best < 0 || i < best)) { best = i; bestLen = w.length }
            }
            if (best >= 0) cmd = src.substring(best + bestLen).trim().trimStart(',', '.', '।', '!', ' ')
        }
        if (cmd == null) { afterListen(); return }
        if (cmd.isBlank()) {
            armedUntil = now + 15000
            speak("जी, बोलिए।")
            return
        }
        val c = cmd.lowercase()
        if (c.contains("सो जाओ") || c.contains("so jao") || c.contains("stop listening") || c.contains("सुनना बंद")) {
            setHandsFree(false)
            stopService(Intent(this, HandsFreeService::class.java))
            speak("ठीक है, मैं आराम कर रही हूँ। जब चाहें ऐप से फिर जगा दीजिए।")
            return
        }
        runCommand(cmd)
    }

    // ---------------- Floating mic bubble ----------------

    private fun setBubble(s: String) { main.post { bubble?.text = s } }

    private fun onBubbleTap() {
        if (running) {
            cancelled = true
            speak("ठीक है, रोक दिया।")
        } else {
            tts?.stop()
            speaking.set(0)
            main.removeCallbacks(listenRunnable)
            startRecognizer(true)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun addBubble() {
        val tv = TextView(this)
        tv.text = "🎤"
        tv.textSize = 26f
        tv.gravity = Gravity.CENTER
        tv.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColors(intArrayOf(0xFF7C4DFF.toInt(), 0xFF00B0FF.toInt()))
        bg.setOrientation(GradientDrawable.Orientation.TL_BR)
        tv.background = bg
        tv.elevation = 12f

        val size = (58 * resources.displayMetrics.density).toInt()
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 24
        lp.y = 500

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt(); val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    lp.x = ox + dx; lp.y = oy + dy
                    wm?.updateViewLayout(tv, lp)
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) onBubbleTap(); true }
                else -> false
            }
        }
        wm?.addView(tv, lp)
        bubble = tv
    }

    private fun buzz() {
        try {
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }

    // ---------------- Agent loop (silent until done) ----------------

    fun runCommand(goal: String) {
        if (running) return
        if (Prefs.key(this).isBlank()) { speak("पहले Gemini API key डालिए।"); return }
        running = true
        cancelled = false
        main.removeCallbacks(listenRunnable)
        main.post { stopRecognizer() }
        setBubble("⏳")
        buzz()
        Thread {
            try {
                val log = StringBuilder()
                var notes = ""
                var report = ""
                var finished = false
                for (step in 1..MAX_STEPS) {
                    if (cancelled) break
                    val screen = snapshot()
                    val shot = if (Prefs.shot(this)) screenshotB64() else null
                    val prompt = "USER COMMAND: $goal\nSTEP: $step of $MAX_STEPS\n\n" +
                        "RECENT CONVERSATION:\n${history.joinToString("\n")}\n\n" +
                        "NOTES SO FAR:\n$notes\n\n" +
                        "PREVIOUS ACTIONS (this command):\n${log.toString().takeLast(1500)}\n\n" +
                        "CURRENT SCREEN:\n$screen"
                    val reply = Gemini.ask(Prefs.key(this), Prefs.model(this), SYSTEM, prompt, shot)
                    val s = reply.indexOf('{'); val e = reply.lastIndexOf('}')
                    val j = JSONObject(reply.substring(s, e + 1))
                    notes = j.optString("notes", notes)
                    val a = j.optJSONObject("action")
                    if (a != null) {
                        val res = execute(a)
                        log.append("Step $step: $a -> $res\n")
                    }
                    if (j.optBoolean("done", false)) {
                        report = j.optString("report", "")
                        finished = true
                        break
                    }
                    Thread.sleep(1200)
                }
                if (!cancelled) {
                    if (!finished) report = "काम थोड़ा लंबा था, पूरा नहीं हो पाया। अब तक मुझे ये पता चला: " + notes.take(300)
                    if (report.isBlank()) report = "काम हो गया। अब क्या करूँ?"
                    speak(report)
                    history.add("User: $goal | Saathi: ${report.take(200)}")
                    while (history.size > 4) history.removeAt(0)
                }
            } catch (ex: Exception) {
                speak("एक दिक्कत आई: " + (ex.message ?: "unknown").take(150))
            } finally {
                running = false
                armedUntil = System.currentTimeMillis() + 15000
                setBubble(idleIcon())
                main.post { if (handsFreeEnabled && speaking.get() == 0) scheduleListen(400) }
            }
        }.start()
    }

    // ---------------- Screen reading ----------------

    private fun snapshot(): String {
        nodeMap.clear()
        val root = rootInActiveWindow ?: return "(screen unavailable)"
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || nodeMap.size >= 200) return
            if (n.isVisibleToUser) {
                val t = n.text?.toString()?.take(200) ?: ""
                val d = n.contentDescription?.toString()?.take(100) ?: ""
                val h = if (Build.VERSION.SDK_INT >= 26) (n.hintText?.toString()?.take(40) ?: "") else ""
                if (t.isNotEmpty() || d.isNotEmpty() || h.isNotEmpty() || n.isClickable || n.isEditable) {
                    val idx = nodeMap.size
                    nodeMap.add(n)
                    sb.append("[$idx] ").append(n.className?.toString()?.substringAfterLast('.') ?: "View")
                    if (t.isNotEmpty()) sb.append(" text=\"").append(t).append("\"")
                    if (d.isNotEmpty()) sb.append(" desc=\"").append(d).append("\"")
                    if (h.isNotEmpty()) sb.append(" hint=\"").append(h).append("\"")
                    if (n.isClickable) sb.append(" clickable")
                    if (n.isEditable) sb.append(" editable")
                    sb.append('\n')
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return "app=${root.packageName}\n$sb"
    }

    private fun screenshotB64(): String? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var out: String? = null
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                        try {
                            val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                            val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            r.hardwareBuffer.close()
                            if (bmp != null) {
                                val w = 540
                                val h = bmp.height * w / bmp.width
                                val sc = Bitmap.createScaledBitmap(bmp, w, h, true)
                                val bos = ByteArrayOutputStream()
                                sc.compress(Bitmap.CompressFormat.JPEG, 60, bos)
                                out = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
                            }
                        } catch (_: Exception) {}
                        latch.countDown()
                    }
                    override fun onFailure(errorCode: Int) { latch.countDown() }
                })
            latch.await(5, TimeUnit.SECONDS)
        } catch (_: Exception) {}
        return out
    }

    // ---------------- Actions ----------------

    private fun execute(a: JSONObject): String {
        return try {
            when (a.optString("type")) {
                "open_app" -> { val r = openApp(a.optString("name")); Thread.sleep(2500); r }
                "open_url" -> {
                    val i = Intent(Intent.ACTION_VIEW, Uri.parse(a.optString("url"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i); Thread.sleep(3500); "opened url"
                }
                "click" -> {
                    val n = nodeMap.getOrNull(a.optInt("index", -1))
                    if (n == null) "bad index" else "clicked=${clickNode(n)}"
                }
                "long_press" -> {
                    val n = nodeMap.getOrNull(a.optInt("index", -1))
                    if (n == null) "bad index" else {
                        val r = Rect(); n.getBoundsInScreen(r)
                        val p = Path(); p.moveTo(r.centerX().toFloat(), r.centerY().toFloat())
                        "long_pressed=${gesture(p, 900)}"
                    }
                }
                "click_text" -> {
                    val list = rootInActiveWindow?.findAccessibilityNodeInfosByText(a.optString("text"))
                    val n = list?.firstOrNull()
                    if (n == null) "text not found" else "clicked=${clickNode(n)}"
                }
                "type" -> {
                    val n: AccessibilityNodeInfo? = if (a.has("index")) nodeMap.getOrNull(a.optInt("index"))
                    else rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                    if (n == null) "no field" else {
                        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                        val b = Bundle()
                        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, a.optString("text"))
                        val ok = n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
                        if (a.optBoolean("enter", false) && Build.VERSION.SDK_INT >= 30) {
                            Thread.sleep(400)
                            n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
                        }
                        "typed=$ok"
                    }
                }
                "scroll" -> {
                    val dm = resources.displayMetrics
                    val p = Path()
                    val x = dm.widthPixels / 2f
                    if (a.optString("direction") == "up") { p.moveTo(x, dm.heightPixels * 0.3f); p.lineTo(x, dm.heightPixels * 0.7f) }
                    else { p.moveTo(x, dm.heightPixels * 0.7f); p.lineTo(x, dm.heightPixels * 0.3f) }
                    "scrolled=${gesture(p, 350)}"
                }
                "tap" -> "tapped=${tap(a.optDouble("x").toFloat(), a.optDouble("y").toFloat())}"
                "call" -> call(a.optString("target"))
                "alarm" -> {
                    val i = Intent(AlarmClock.ACTION_SET_ALARM)
                        .putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7))
                        .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                        .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Alarm"))
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i); "alarm set"
                }
                "volume" -> {
                    val am = getSystemService(AUDIO_SERVICE) as AudioManager
                    val dir = when (a.optString("direction")) {
                        "up" -> AudioManager.ADJUST_RAISE
                        "down" -> AudioManager.ADJUST_LOWER
                        else -> AudioManager.ADJUST_TOGGLE_MUTE
                    }
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
                    "volume changed"
                }
                "back" -> "back=${performGlobalAction(GLOBAL_ACTION_BACK)}"
                "home" -> "home=${performGlobalAction(GLOBAL_ACTION_HOME)}"
                "recents" -> "recents=${performGlobalAction(GLOBAL_ACTION_RECENTS)}"
                "notifications" -> "ok=${performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)}"
                "quick_settings" -> "ok=${performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)}"
                "lock" -> if (Build.VERSION.SDK_INT >= 28) "ok=${performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)}" else "not supported"
                "screenshot" -> if (Build.VERSION.SDK_INT >= 28) "ok=${performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)}" else "not supported"
                "wait" -> { Thread.sleep((a.optInt("seconds", 2).coerceIn(1, 10) * 1000).toLong()); "waited" }
                else -> "unknown action"
            }
        } catch (e: Exception) {
            "error: ${e.message}"
        }
    }

    private fun clickNode(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        var hops = 0
        while (c != null && !c.isClickable && hops < 5) { c = c.parent; hops++ }
        if (c != null && c.isClickable && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        val r = Rect()
        n.getBoundsInScreen(r)
        return tap(r.centerX().toFloat(), r.centerY().toFloat())
    }

    private fun tap(x: Float, y: Float): Boolean {
        val p = Path()
        p.moveTo(x, y)
        return gesture(p, 60)
    }

    private fun gesture(path: Path, dur: Long): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
        val started = dispatchGesture(g, object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }, null)
        if (!started) return false
        latch.await(3, TimeUnit.SECONDS)
        return ok
    }

    private fun openApp(name: String): String {
        val pm = packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = pm.queryIntentActivities(i, 0)
        val q = name.lowercase().trim()
        val m = list.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: list.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: list.firstOrNull { it.activityInfo.packageName.lowercase().contains(q) }
            ?: return "app not found"
        val li = pm.getLaunchIntentForPackage(m.activityInfo.packageName) ?: return "cannot launch"
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(li)
        return "opened ${m.activityInfo.packageName}"
    }

    private fun call(target: String): String {
        var number = target.filter { it.isDigit() || it == '+' }
        if (number.length < 5) {
            val cur = contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                arrayOf("%$target%"), null
            )
            var found: String? = null
            cur?.use { if (it.moveToFirst()) found = it.getString(1) }
            number = found ?: return "contact not found"
        }
        val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
        return "calling"
    }
}
